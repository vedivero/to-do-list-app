# to-do-list-app

할 일 목록을 생성하고, 완료된 할 일은 완료로 표시하며, 사용자가 원하는 항목을 삭제할 수 있는 애플리케이션

## back-end
express, mongoose, restful API
